#!/bin/bash

clear ;

FILE=./app/mysql-connector-j-8.0.33.jar
if [ ! -f "$FILE" ]; then
    curl https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar -O ./app/
fi

cd app/;
mvn clean package;
cd ..

docker compose cp ./app/target/agenda.war agendaapp:/opt/jboss/wildfly/standalone/deployments/
