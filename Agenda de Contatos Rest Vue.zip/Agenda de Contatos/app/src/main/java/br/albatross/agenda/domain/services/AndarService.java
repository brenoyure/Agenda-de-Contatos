package br.albatross.agenda.domain.services;

import java.util.List;

import br.albatross.agenda.domain.dao.AndarDao;
import br.albatross.agenda.domain.models.Andar;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

@RequestScoped
public class AndarService {

	@Inject
	private AndarDao dao;

	public List<Andar> listar() {
		return dao.listar();
	}
}
