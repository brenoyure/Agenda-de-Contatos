package br.albatross.agenda.domain.models.contato;

public record ContatoDto(
		
		Number id,
		String nome, 
		String ramal, 
		String siglaDoSetor
		
	) {

}
