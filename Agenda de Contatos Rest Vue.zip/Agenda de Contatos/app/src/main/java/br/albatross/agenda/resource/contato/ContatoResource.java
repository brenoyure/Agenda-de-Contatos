package br.albatross.agenda.resource.contato;

import static jakarta.ws.rs.core.MediaType.APPLICATION_JSON;

import br.albatross.agenda.domain.services.ContatoService;
import jakarta.inject.Inject;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Response;

@Path("/contato")
public class ContatoResource {

	@Inject
	private ContatoService service;

	@GET
	@Produces(APPLICATION_JSON)
	public Response listarContatos(@QueryParam("pagina") int pagina) {
		return Response.ok(service.listar(pagina)).header("Access-Control-Allow-Origin", "*").build();
	}

}
