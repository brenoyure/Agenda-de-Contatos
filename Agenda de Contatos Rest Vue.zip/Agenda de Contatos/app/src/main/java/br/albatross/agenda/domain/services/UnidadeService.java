package br.albatross.agenda.domain.services;

import java.util.List;

import br.albatross.agenda.domain.dao.UnidadeAdministrativaDao;
import br.albatross.agenda.domain.models.UnidadeAdministrativa;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

@RequestScoped
public class UnidadeService {

	@Inject
	private UnidadeAdministrativaDao dao;

	public void salvar(UnidadeAdministrativa unidadeAdministrativa) {
			dao.persist(unidadeAdministrativa);
	}

	public void atualizar(UnidadeAdministrativa unidadeAdministrativa) {
		dao.atualizar(unidadeAdministrativa);
	}

	public List<UnidadeAdministrativa> listar() {
		return dao.listar();
	}

	public void excluir(UnidadeAdministrativa unidadeAdministrativa) {
		dao.excluir(unidadeAdministrativa);
	}

	public boolean existePorId(Short unidadeId) {
		return dao.existePorId(unidadeId);
	}

	public UnidadeAdministrativa carregar(Short unidadeId) {
		return dao.carregar(unidadeId);
	}

}
