package br.albatross.agenda.domain.services;

import java.util.List;

import br.albatross.agenda.domain.dao.ContatoDao;
import br.albatross.agenda.domain.models.contato.Contato;
import br.albatross.agenda.domain.models.contato.ContatoDto;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

@RequestScoped
public class ContatoService {

	@Inject
	private ContatoDao dao;

	public void salvar(Contato contato) {
		dao.persist(contato);
	}

	public List<ContatoDto> listar(int pagina) {
		return dao.listar(pagina);
	}

	public Contato buscarPorId(Number contatoId) {
		return dao.buscarPorId(contatoId);
	}

	public void excluir(Contato contato) {
		dao.excluir(contato);
	}

}
