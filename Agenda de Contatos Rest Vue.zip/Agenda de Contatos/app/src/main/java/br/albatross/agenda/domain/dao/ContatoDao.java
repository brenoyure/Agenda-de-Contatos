package br.albatross.agenda.domain.dao;

import java.util.List;

import org.hibernate.jpa.AvailableHints;

import br.albatross.agenda.domain.models.contato.Contato;
import br.albatross.agenda.domain.models.contato.ContatoDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@ApplicationScoped
public class ContatoDao {

	@PersistenceContext
	private EntityManager entityManager;

	public void persist(Contato contato) {
		entityManager.persist(contato);
	}

	public void atualizar(Contato contato) {
		entityManager.merge(contato);
	}

	public boolean existePorNome(String nome) {
		return entityManager
				.createQuery("SELECT EXISTS(SELECT c FROM Contato c WHERE c.nome = ?1)", Boolean.class)
				.setParameter(1, nome)
				.setHint(AvailableHints.HINT_CACHEABLE, true)
				.getSingleResult();
	}
	
	public boolean existePorId(Short contatoId) {
		return entityManager
				.createQuery("SELECT EXISTS (SELECT c FROM Contato c WHERE c.id = ?1)", Boolean.class)
				.setParameter(1, contatoId)
				.setHint(AvailableHints.HINT_CACHEABLE, true)
				.getSingleResult();
	}

	public List<ContatoDto> listar(int pagina) {
		return entityManager
				.createQuery("SELECT new br.albatross.agenda.domain.models.contato.ContatoDto(c.id, c.nome, c.numero, s.sigla) FROM Contato c JOIN c.setor s", ContatoDto.class)
				.setFirstResult(pagina-=1)
				.setMaxResults(1)
				.setHint(AvailableHints.HINT_CACHEABLE, true)
				.getResultList();
	}

	public Contato buscarPorId(Number contatoId) {
		return entityManager.find(Contato.class, contatoId);
	}

	public void excluir(Contato contato) {
		entityManager.remove(entityManager.getReference(Contato.class, contato.getId()));
	}



}
