package br.albatross.agenda.domain.services;

import java.util.List;

import br.albatross.agenda.domain.dao.SetorDao;
import br.albatross.agenda.domain.models.Setor;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

@RequestScoped
public class SetorService {

	@Inject
	private SetorDao dao;

	public void salvar(Setor setor) {
		dao.persist(setor);
	}

	public boolean existePorId(Short setorId) {
		return dao.existePorId(setorId);
	}	

	public List<Setor> listar() {
		return dao.listar();
	}

	public void atualizar(Setor setor) {
		dao.atualizar(setor);
	}

	public Setor carregar(Short setorId) {
		return dao.carregar(setorId);
	}

	public void excluir(Setor setor) {
		dao.excluir(setor);
		
	}

}
