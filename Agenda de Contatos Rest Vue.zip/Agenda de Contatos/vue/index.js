const API = 'http://localhost:8080/agenda/contato'

const myAppComponent = {
    data() {
        return {
            contatos: {},
            pagina: 1,
            paginas: [1, 2]
        }
    },

    methods: {
        async fetchApi() {
            await axios.get(API, {
                params: {
                    pagina: this.pagina
                  }
            })
            .then((response) => {
                this.contatos = response.data
            })
            .catch((error) => {
                console.log(error)
            })
        },

        getContatos(pagina) {
            this.pagina = pagina
            this.fetchApi()
        }
    },

    mounted() {
        this.fetchApi()
    }
}

const myApp = Vue.createApp(myAppComponent).mount('#myapp')
